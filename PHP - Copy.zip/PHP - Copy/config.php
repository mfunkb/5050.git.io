<?php

$conn = mysqli_connect('localhost','root','abelpro','SkateBoy') or die('connection failed');

?>